public class Cliente {
    private String rut;
    private String correo;
    private String nombre;
    private int telefono;
    private String direccion;
    private boolean clienteCreado;
//
    public Cliente(String rut, String correo, String nombre, int telefono, String direccion, boolean clienteCreado) {
        this.rut = rut;
        this.correo = correo;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.clienteCreado = clienteCreado;
    }
//
    public Cliente() {
        this.rut = "";
        this.correo = "";
        this.nombre = "";
        this.telefono = 0;
        this.direccion = "";
        this.clienteCreado = false;
    }  
//
    
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        if(rut.trim().length() == 0)
        {
            System.out.println("=========== Error: Rut no especificado");
        }
        
        else
            this.rut = rut;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre.trim().length() == 0)
        {
            System.out.println("=========== Error: Nombre no especificado");
        }
        else
            this.nombre = nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
//
    public String mostrarCliente() {
        return "\n===== Cliente =====" +
               "\nRut         : " + rut +
               "\nNombre      : " + nombre +
               "\nDireccion   : " + direccion +
               "\nTelefono    :" + telefono +
               "\nCorreo      :" + correo;
    }

    public boolean isClienteCreado() {
        return clienteCreado;
    }

    public void setClienteCreado(boolean clienteCreado) {
        this.clienteCreado = clienteCreado;
    }

}
