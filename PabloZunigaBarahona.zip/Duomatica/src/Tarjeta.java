
public class Tarjeta {
    private String numeroDeTarjeta;
    private int saldo;
    private Cliente cliente;
    private String fechaCaducidad;
    private boolean primeraCompra;
    private int cobroDeCompra;
    private boolean tarjetaCreada;
//
    public Tarjeta(String numeroDeTarjeta, int Saldo, Cliente cliente, String fechaCaducidad, boolean primeraCompra, int cobroDeCompra, boolean tarjetaCreada) {
        this.numeroDeTarjeta = numeroDeTarjeta;
        this.saldo = Saldo;
        this.cliente = cliente;
        this.fechaCaducidad = fechaCaducidad;
        this.primeraCompra = primeraCompra;
        this.cobroDeCompra = cobroDeCompra;
        this.tarjetaCreada = tarjetaCreada;
    }
    public Tarjeta() {
        this.numeroDeTarjeta = "";
        this.saldo = 0;
        this.cliente = new Cliente();
        this.fechaCaducidad = "";
        this.primeraCompra = true;
        this.cobroDeCompra = 0;
        this.tarjetaCreada = false;
    }
//

    public boolean isTarjetaCreada() {
        return tarjetaCreada;
    }

    public void setTarjetaCreada(boolean tarjetaCreada) {
        this.tarjetaCreada = tarjetaCreada;
    }
    
    public int getCobroDeCompra() {
        return cobroDeCompra;
    }

    public void setCobroDeCompra(int cobroDeCompra) {
        this.cobroDeCompra = cobroDeCompra;
    }
    
    public String getNumeroDeTarjeta() {
        return numeroDeTarjeta;
    }

    public void setNumeroDeTarjeta(String numeroDeTarjeta) {
        if(numeroDeTarjeta.trim().length() == 0)
        {
            System.out.println("=========== Error: Numero de tarjeta no especificado");
        }
        else
            this.numeroDeTarjeta = numeroDeTarjeta;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        if(saldo <= 0)
        {
            System.out.println("=========== El saldo debe ser mayor a $0");
            this.saldo = 0;
        }
        else
            this.saldo = saldo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }

    public boolean isPrimeraCompra() {
        return primeraCompra;
    }

    public void setPrimeraCompra(boolean primeraCompra) {
        this.primeraCompra = primeraCompra;
    }
//

    public String imprimirTarjeta() {
        return  "\n=============== Datos Tarjeta ===============" +
                "\nNumero de tarjeta   : " + numeroDeTarjeta +
                "\nTitular             : " + cliente.getNombre() +
                "\nSaldo               : $" + saldo +
                "\nFecha de caducidad  : " + fechaCaducidad + 
                "\nCliente nuevo       : " + (primeraCompra?"Si":"No");
    }
   
    public void cashBack(){
        if(cobroDeCompra <= 200000)
        {
            this.cobroDeCompra = (int) (cobroDeCompra*0.05);
        }
        else
        {    
            System.out.println("=========== Limite de CashBack $10.000");
            this.cobroDeCompra = 0;
        }
    }
    public String reporteCorreo()
    {
        return "\n*********************************************************************"+
               "\n Correo: "+cliente.getCorreo().toUpperCase()+
               "\n Estimado: "+cliente.getNombre()+
               "\n Se ha registrado actividad en su tarjeta "+this.numeroDeTarjeta.toUpperCase()+
               "\n\n Si no reconoce esta actividad, por favor informe a\n servicio al cliente o  bloquee la tarjeta."+
               "\n ¡Gracias por ser parte de DUOMATICA!";
                
    }

}
