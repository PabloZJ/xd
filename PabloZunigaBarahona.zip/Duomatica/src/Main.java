import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner leerTeclado = new Scanner(System.in);
        int opc = -1;
        Cliente cliente1 = new Cliente();
        Cliente cliente2 = new Cliente();
        Tarjeta tarjeta1 = new Tarjeta();
        Tarjeta tarjeta2 = new Tarjeta();
        while(opc != 0){
            
            System.out.println("\n=============== MENU ===============");
            System.out.println(" 1. Crear Cliente");
            System.out.println(" 2. Crear Tarjetas");
            System.out.println(" 3. Mostrar informacion tarjetas");
            System.out.println(" 4. Realizar compra Cliente Nuevo");
            System.out.println(" 5. Realizar compra Cliente Antiguo");
            System.out.println(" 6. Realizar Abono");
            System.out.println(" 7. Salir");
            System.out.print(" - Opcion: ");
            opc = leerTeclado.nextInt();
            
            if (opc == 7)
            {
                break;
            }
            else if(opc == 1)
            {
                if(cliente1.isClienteCreado() == false && cliente2.isClienteCreado() == false)
                {
                cliente1.setRut("21951061-3");
                cliente1.setNombre("Pablo Zuniga");
                cliente1.setDireccion("Tegualda");
                cliente1.setTelefono(977454172);
                cliente1.setCorreo("pablo123@gmail.com");
                        
                cliente2.setRut("21951062-7");
                cliente2.setNombre("Juan Perez");
                cliente2.setDireccion("Los presidentes");
                cliente2.setTelefono(977882151);
                cliente2.setCorreo("juan123@gmail.com");
                cliente1.setClienteCreado(true);
                cliente2.setClienteCreado(true);
                System.out.println("*********** Clientes creados ***********");
                }
                else
                    System.out.println("=========== Cliente ya creado :)");
            }
            else if(opc == 2)
            {   
                if(cliente1.isClienteCreado() == true && cliente2.isClienteCreado() && true && tarjeta1.isTarjetaCreada() == false && tarjeta2.isTarjetaCreada() == false)
                {
                    tarjeta1.setCliente(cliente1);
                    tarjeta1.setNumeroDeTarjeta("214 151 454");
                    tarjeta1.setFechaCaducidad("06/30");
                    tarjeta1.setSaldo(500000);
                    tarjeta1.setPrimeraCompra(true);

                    tarjeta2.setCliente(cliente2);
                    tarjeta2.setNumeroDeTarjeta("142 441 514");
                    tarjeta2.setFechaCaducidad("08/29");
                    tarjeta2.setSaldo(500000);
                    tarjeta2.setPrimeraCompra(true);
                    System.out.println("*********** Tarjetas creados ***********");
                    tarjeta1.setTarjetaCreada(true);
                    tarjeta2.setTarjetaCreada(true);
                }
                else
                    System.out.println("=========== Cliente aun no creado o ya ha sido creada la tarjeta :)");
            }
            else if(opc == 3 && cliente1.isClienteCreado() == true && cliente2.isClienteCreado() == true && tarjeta1.isTarjetaCreada() == true && tarjeta2.isTarjetaCreada() == true)
            {
                System.out.println("\n****** Mostrar Datos *******");
                System.out.println(tarjeta1.imprimirTarjeta());
                System.out.println(tarjeta2.imprimirTarjeta());
            }
            else if(opc == 4 && cliente1.isClienteCreado() == true && cliente2.isClienteCreado() == true && tarjeta1.isTarjetaCreada() == true && tarjeta2.isTarjetaCreada() == true)
            {   
                int opcClienteNuevo = -1;
                while(opcClienteNuevo != 0)
                {
                    System.out.println("\n********** Seleccione Cuenta**********");
                    System.out.println(" 1. "+tarjeta1.getCliente().getNombre());
                    System.out.println(" 2. "+tarjeta2.getCliente().getNombre());
                    System.out.println(" 3. Salir");
                    System.out.print("-Opcion: ");
                    opcClienteNuevo = leerTeclado.nextInt();

                    if(opcClienteNuevo == 3)
                        break;
                    
                    else if(opcClienteNuevo == 1 && tarjeta1.isPrimeraCompra() == true)
                    {
                        System.out.println("\n********* Cobro Cliente Nuevo *********");
                        System.out.println("Cliente: "+tarjeta1.getCliente().getNombre());
                        System.out.println("# CashBack de 5% por compra, limite de compra para cashback $200.000");
                        System.out.print(" Monto a pagar: $");
                        int monto = leerTeclado.nextInt();
                        if(monto < tarjeta1.getSaldo())
                        {
                            tarjeta1.setCobroDeCompra(monto);
                            tarjeta1.cashBack();
                            tarjeta1.setSaldo(tarjeta1.getSaldo()-monto+tarjeta1.getCobroDeCompra());
                            System.out.println(tarjeta1.imprimirTarjeta());
                            System.out.println("CashBack            : $"+tarjeta1.getCobroDeCompra());
                            System.out.println(tarjeta1.reporteCorreo());
                            tarjeta1.setCobroDeCompra(0);
                            tarjeta1.setPrimeraCompra(false);
                        }
                        else
                            System.out.println("=========== Saldo insuficiente, vuelva a intentar agregando saldo");
                    }
                    else if(opcClienteNuevo == 2 && tarjeta2.isPrimeraCompra() == true)
                    {
                        System.out.println("********* Cobro Cliente Nuevo *********");
                        System.out.println("Cliente: "+tarjeta2.getCliente().getNombre());
                        System.out.println("# CashBack de 5% por compra, limite de compra para cashback $200.000");
                        System.out.print(" Monto a pagar: $");
                        int monto = leerTeclado.nextInt();
                        if(monto < tarjeta2.getSaldo())
                        {
                            tarjeta2.setCobroDeCompra(monto);
                            tarjeta2.cashBack();
                            tarjeta2.setSaldo(tarjeta2.getSaldo()-monto+tarjeta2.getCobroDeCompra());
                            System.out.println(tarjeta2.imprimirTarjeta());
                            System.out.println("CashBack            : $"+tarjeta2.getCobroDeCompra());
                            System.out.println(tarjeta2.reporteCorreo());
                            tarjeta2.setCobroDeCompra(0);
                            tarjeta2.setPrimeraCompra(false);
                        }
                        else
                            System.out.println("=========== Saldo insuficiente, vuelva a intentar agregando saldo");
                    }
                    else
                        System.out.println("=========== Error: Opcion no válida o usted no es Cliente Nuevo");
                }
            }
            else if(opc == 5 && cliente1.isClienteCreado() == true && cliente2.isClienteCreado() == true && tarjeta1.isTarjetaCreada() == true && tarjeta2.isTarjetaCreada() == true)
            {
                int opcClienteAntiguo = -1;
                while(opcClienteAntiguo != 0)
                {
                    System.out.println("********** Seleccione Cuenta**********");
                    System.out.println(" 1. "+tarjeta1.getCliente().getNombre());
                    System.out.println(" 2. "+tarjeta2.getCliente().getNombre());
                    System.out.println(" 3. Salir");
                    System.out.print("-Opcion: ");
                    opcClienteAntiguo = leerTeclado.nextInt();

                    if(opcClienteAntiguo == 3)
                        break;
                    
                    else if(opcClienteAntiguo == 1 && tarjeta1.isPrimeraCompra() == false)
                    {
                        System.out.println("********* Cobro Cliente Antiguo *********");
                        System.out.println("Cliente: "+tarjeta1.getCliente().getNombre());
                        System.out.print(" Monto a pagar: $");
                        int monto = leerTeclado.nextInt();
                        if(monto < tarjeta1.getSaldo())
                        {
                            tarjeta1.setSaldo(tarjeta1.getSaldo()-monto);
                            System.out.println(tarjeta1.imprimirTarjeta());
                            System.out.println(tarjeta1.reporteCorreo());
                        }
                        else
                            System.out.println("=========== Saldo insuficiente, vuelva a intentar agregando saldo");
                    }
                    else if(opcClienteAntiguo == 2 && tarjeta2.isPrimeraCompra() == false)
                    {
                        System.out.println("\n********* Cobro Cliente Antiguo *********");
                        System.out.println("Cliente: "+tarjeta2.getCliente().getNombre());
                        System.out.print(" Monto a pagar: $");
                        int monto = leerTeclado.nextInt();
                        if(monto < tarjeta2.getSaldo())
                        {
                            tarjeta2.setSaldo(tarjeta2.getSaldo()-monto);
                            System.out.println(tarjeta2.imprimirTarjeta());
                            System.out.println(tarjeta2.reporteCorreo());
                        }
                        else
                            System.out.println("=========== Saldo insuficiente, vuelva a intentar agregando saldo");
                    }
                    else
                        System.out.println("=========== Error: Opcion no válida");
                }
            }
            else if(opc == 6 && cliente1.isClienteCreado() == true && cliente2.isClienteCreado() == true && tarjeta1.isTarjetaCreada() == true && tarjeta2.isTarjetaCreada() == true)
            {
                int opcClienteAbono = -1;
                while(opcClienteAbono != 0)
                {
                    System.out.println("********** Seleccione Cuenta**********");
                    System.out.println(" 1. "+tarjeta1.getCliente().getNombre());
                    System.out.println(" 2. "+tarjeta2.getCliente().getNombre());
                    System.out.println(" 3. Salir");
                    System.out.print("-Opcion: ");
                    opcClienteAbono = leerTeclado.nextInt();

                    if(opcClienteAbono == 3)
                    {
                        break;
                    }
                    else if(opcClienteAbono == 1)
                    {
                        System.out.print("Monto para abonar: $");
                        int monto = leerTeclado.nextInt();
                        tarjeta1.setSaldo(tarjeta1.getSaldo()+monto);
                        System.out.println("****** El abono se ha realizado con exito *******");
                        System.out.println(tarjeta1.reporteCorreo());
                    }
                    else if(opcClienteAbono == 2)
                    {
                        System.out.print("Monto para abonar: $");
                        int monto = leerTeclado.nextInt();
                        tarjeta2.setSaldo(tarjeta2.getSaldo()+monto);
                        System.out.println("****** El abono se ha realizado con exito *******");
                        System.out.println(tarjeta2.reporteCorreo());
                    }
                    else
                        System.out.println("=========== Opcion no valida");
                }
            }
            else
            {
                System.out.println("=========== Opcion no valida.");
            }
            System.out.println("Presione C y Enter para continuar");
            leerTeclado.next();
        }
    }
}